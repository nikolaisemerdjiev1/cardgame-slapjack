import java.util.LinkedList;

/**
 * Class that creates a Player object
 */
public class Player {
    private int playerNum;
    private LinkedList<Card> hand;
    private String pattern;

    /**
     * Overloaded constructor to make a player
     * 
     * @param playerNum Number corresponding to the player
     * @param hand      Hand of the player
     * @param pattern   Pattern they are looking for
     */
    public Player(int playerNum, LinkedList<Card> hand, String pattern) {
        this.playerNum = playerNum;
        this.hand = hand;
        this.pattern = randomPattern();
    }

    /**
     * Assigning a random pattern to each player
     */
    private String randomPattern() {
        String[] patterns = new String[] { "doubles", "top bottom", "sandwich" };
        return patterns[(int) (Math.random() * patterns.length)];
    }

    /**
     * Playing a card from the player's hand
     * 
     * @return Card that represents the top card in the pile
     */
    public Card playCard() {
        Card removedCard = this.hand.removeFirst();
        return removedCard;

    }

    /**
     * Access the static methods in game depending on what pattern the player has
     * 
     * @param pile
     * @return true or false whether they can actually slap
     */
    public boolean slaps(LinkedList<Card> pile) {
        if (pattern.equals("doubles")) {
            return Game.doubles(pile);
        } else if (pattern.equals("sandwich")) {
            return Game.sandwich(pile);
        } else if (pattern.equals("top bottom")) {
            return Game.topBottom(pile);
        } else {
            return false;
        }
    }

    /**
     * Accessor methods
     * 
     * @return member variables
     */
    public int getPlayerNum() {
        return playerNum;
    }

    public LinkedList<Card> getHand() {
        return hand;
    }

    public String getPattern() {
        return pattern;
    }

    /**
     * Display of a player
     */
    public String toString() {
        return "~~~~~~~~~~~~~~~~\n" +
                "Player Number " + getPlayerNum() + ": \n " +
                "Watching for " + getPattern() +
                "\nCurrent hand: \n" + getHand() +
                "~~~~~~~~~~~~~~~~\n";
    }

}
